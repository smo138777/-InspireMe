const quotes = [
    "Believe in yourself!",
    "You are capable of amazing things.",
    "Push yourself, because no one else is going to do it for you.",
    "Success doesn't come to you, you go to it.",
    "Don't watch the clock; do what it does. Keep going.",
    "Your only limit is your mind."
];

function showQuote() {
    const randomIndex = Math.floor(Math.random() * quotes.length);
    const randomQuote = quotes[randomIndex];
    document.getElementById("quoteDisplay").textContent = randomQuote;
}
